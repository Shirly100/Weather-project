﻿namespace System.Web.UI
{
    public class Page
    {
    }
}