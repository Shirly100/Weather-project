﻿using System;
using System.Net;
using Newtonsoft.Json;
using BE;
using static BE.WeatherInfo;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    {
        /// <summary>
        /// fetching weather data from openweathermap API
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            using (WebClient web = new WebClient())
            {
                string City = "Jerusalem";
                string url_ = "http://api.openweathermap.org/data/2.5/weather?q=";
                url_ += City;
                url_ += "&APPID=3abb8efaa3e00114b3a644f26bf7626d";
                string url = string.Format(url_);
                var json = web.DownloadString(url);
                //System.Console.WriteLine(json);
                var result = JsonConvert.DeserializeObject<WeatherInfo.root>(json);
                WeatherInfo.root output = result;
                //output.weatherList = new List<weather>();
                Console.WriteLine(string.Format("{0}", output.main.humidity));
                //Console.WriteLine(string.Format("{0}", output.weatherList[0].description));
            }

        }
    }
}

